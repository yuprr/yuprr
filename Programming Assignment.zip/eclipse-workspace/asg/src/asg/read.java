package asg;

import java.io.File;
import java.io.IOException;
import java.util.Locale;

import jxl.LabelCell;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

public class read {

    public static void main(String[] args) {
        try {
            // Create a new workbook
            WorkbookSettings wbSettings = new WorkbookSettings();
            wbSettings.setLocale(new Locale("en", "EN"));
            WritableWorkbook workbook = Workbook.createWorkbook(new File("C:\\Users\\Asus\\Desktop\\BookstoreInventory.xlsx"), wbSettings);

            // Create three sheets: Inventory, Sales History, Customers
            WritableSheet inventorySheet = workbook.createSheet("Inventory", 0);
            WritableSheet salesHistorySheet = workbook.createSheet("Sales History", 1);
            WritableSheet customersSheet = workbook.createSheet("Customers", 2);

            // Add headers to the sheets
            addHeaders(inventorySheet, new String[]{"Title", "Aurthor", "Genre", "Price", "Quantity"});
            addHeaders(salesHistorySheet, new String[]{"Transaction ID", "Date", "Book ID", "Quantity Sold", "Total Revenue"});
            addHeaders(customersSheet, new String[]{"Customer ID", "Name", "Email", "Phone"});

            // Add data to the sheets (you can modify this part based on your actual data)
            addData(inventorySheet, 1, new String[]{"001", "The GreatGatsby", "F. Scott Fitzgerald", "Fiction", "12.99", "100"});
            addData(inventorySheet, 2, new String[]{"002", "To Kill a Mockingbird", "Harper Lee", "Fiction", "15.99", "75"});
            addData(inventorySheet, 3, new String[]{"003", "1984", "George Orwell", "Dystopian", "10.99", "120"});
            addData(inventorySheet, 4, new String[]{"004", "Pride and Prejudice", "Jane Austen", "Romance", "9.99", "90"});
            addData(inventorySheet, 5, new String[]{"005", "The Catcher in the Rye", "J.D. Salinger", "Fiction", "14.99", "80"});
            addData(inventorySheet, 6, new String[]{"006", "The Hobbit", "J.R.R. Tolkien", "Fantasy", "18.99", "60"});
            addData(inventorySheet, 7, new String[]{"007", "The Da Vinci Code", "Dan Brown", "Mystery", "17.99", "110"});
            addData(inventorySheet, 8, new String[]{"008", "The Hunger Games", "Suzanne Collins", "Sci-Fi", "13.99", "95"});
            addData(inventorySheet, 9, new String[]{"009", "The Shining", "Stephen King", "Horror", "16.99", "70"});
            addData(inventorySheet, 10, new String[]{"010", "Harry Potter and the Sorcerer's Stone", "J.K. Rowling", "Fantasy", "20.99", "85"});
            
            
            addData(salesHistorySheet, 1, new String[]{"001", "1/1/2023 8:00 AM", "3", "5", "54.95"});
            addData(salesHistorySheet, 2, new String[]{"002", "1/2/2023 10:30 AM", "6", "2", "37.98"});
            addData(salesHistorySheet, 3, new String[]{"003", "1/3/2023 15:45 PM", "8", "10", "179.9"});
            addData(salesHistorySheet, 4, new String[]{"004", "1/4/2023 12:15 PM", "2", "3", "47.97"});
            addData(salesHistorySheet, 5, new String[]{"005", "1/5/2023 17:30 PM", "10", "7", "146.93"});

            addData(customersSheet, 1, new String[]{"001", "John Doe", "john.doe@email.com", "012-3456-789"});
            addData(customersSheet, 2, new String[]{"002", "Jane Smith", "jane.smith@email.com", "012-3456-790"});
            addData(customersSheet, 3, new String[]{"003", "Bob Johnson", "bob.johnson@email.com", "012-3456-791"});
            addData(customersSheet, 4, new String[]{"004", "Emily White", "emily.white@email.com", "012-3456-792"});
            addData(customersSheet, 5, new String[]{"005", "Alex Turner", "alex.turner@email.com", "012-3456-793"});

            // Write the workbook to the file
            workbook.write();
            workbook.close();

            System.out.println("Excel file created successfully.");

        } catch (IOException | WriteException e) {
            e.printStackTrace();
            System.out.println("Error creating Excel file.");
        }
    }

    private static void addHeaders(WritableSheet sheet, String[] headers) throws WriteException {
        for (int i = 0; i < headers.length; i++) {
            Label headerLabel = new Label(i, 0, headers[i]);
            sheet.addCell(headerLabel);
        }
    }

    private static void addData(WritableSheet sheet, int row, String[] data) throws WriteException {
        for (int i = 0; i < data.length; i++) {
            Label dataLabel = new Label(i, row, data[i]);
            sheet.addCell(dataLabel);
        }
    }
}


