package asg;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import java.io.File;
import java.io.IOException;

public class read2 {

    public static void main(String[] args) {
        String filePath = "C:\\Users\\Asus\\Desktop\\BookstoreInventory.xlsx";  // Update with your file path

        try {
            Workbook workbook = Workbook.getWorkbook(new File(filePath));

            // Assuming data is present in the first sheet (Inventory)
            Sheet sheet = workbook.getSheet(0);

            int rows = sheet.getRows();
            int columns = sheet.getColumns();

            // Print column headers
            for (int j = 0; j < columns; j++) {
                Cell cell = sheet.getCell(j, 0);
                System.out.print(cell.getContents() + "\t");
            }
            System.out.println();

            // Print data
            for (int i = 1; i < rows; i++) {
                for (int j = 0; j < columns; j++) {
                    Cell cell = sheet.getCell(j, i);
                    System.out.print(cell.getContents() + "\t");
                }
                System.out.println(); // Move to the next line after each row
            }

            workbook.close();
        } catch (IOException | BiffException e) {
            e.printStackTrace();
        }
    }
}